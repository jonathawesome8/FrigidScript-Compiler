//canvas setup
var fsCanvas = document.getElementById("fsCanvas");
var fsContext = fsCanvas.getContext("2d");

//variables
var fontSize = 12;
var fsConsole = [];